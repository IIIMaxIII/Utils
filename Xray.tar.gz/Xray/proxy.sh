#!/bin/bash

XRAY_CONFIG="/TEST/Xray/config.json"
XRAY_BIN="/TEST/Xray/xray"
PID_FILE="/tmp/xray.pid"

get_ips() {
    echo -n "IPv4: $(curl -4 -s https://ifconfig.me 2>/dev/null || echo '❌ недоступен')"
    echo " | IPv6: $(curl -6 -s https://ifconfig.me 2>/dev/null || echo '❌ недоступен')"
}

proxy_on() {
    # Запускаем Xray если не запущен
    if ! pgrep -f "xray run" > /dev/null; then
        nohup "$XRAY_BIN" run -config "$XRAY_CONFIG" > /dev/null 2>&1 &
        echo $! > "$PID_FILE"
        sleep 2
        echo "✅ Xray запущен"
    fi
    
    # Устанавливаем переменные
    export ALL_PROXY=socks5h://127.0.0.1:10808
    export HTTP_PROXY=socks5h://127.0.0.1:10808
    export HTTPS_PROXY=socks5h://127.0.0.1:10808
    export SOCKS_PROXY=socks5h://127.0.0.1:10808
    
    echo "✅ Прокси включен"
    get_ips
}

proxy_off() {
    # Убираем переменные
    unset ALL_PROXY HTTP_PROXY HTTPS_PROXY SOCKS_PROXY
    
    # Останавливаем Xray
    if [ -f "$PID_FILE" ]; then
        kill $(cat "$PID_FILE") 2>/dev/null
        rm -f "$PID_FILE"
    fi
    pkill -f "xray run"
    
    echo "❌ Прокси выключен"
    get_ips
}

proxy_status() {
    echo "=== Статус прокси ==="
    echo "Переменные: ${ALL_PROXY:-не установлены}"
    echo "Xray: $(pgrep -f "xray run" > /dev/null && echo '✅ запущен' || echo '❌ не запущен')"
    echo "Порт: $(ss -tlnp | grep -q 10808 && echo '✅ 10808 слушает' || echo '❌ 10808 не слушает')"
    
    if [ -n "$ALL_PROXY" ] && pgrep -f "xray run" > /dev/null; then
        echo "Текущие IP:"
        get_ips
    else
        echo "Прямое подключение:"
        get_ips
    fi
}

case "$1" in
    on) proxy_on ;;
    off) proxy_off ;;
    status) proxy_status ;;
    *) echo "Использование: . $0 {on|off|status}" ;;
esac